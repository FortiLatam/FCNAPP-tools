import json
import logging
import boto3
import os
from botocore.exceptions import BotoCoreError, ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)

ec2_client = boto3.client('ec2')

def lambda_handler(event, context):
    logger.info("Event received")
    try:
        detail_data = event.get("detail", {})
        instance_id = (
            detail_data.get("EVENT_DETAILS", {}).get("data", [{}])[0]
            .get("ENTITY_MAP", {}).get("Machine", [{}])[0]
            .get("INSTANCE_ID")
        )
        
        if not instance_id:
            logger.error("INSTANCE_ID not found.")
            return {"statusCode": 400, "body": "INSTANCE_ID not found."}

        vpc_id = get_vpc_id(instance_id)
        security_group_name = os.getenv('SECURITY_GROUP_NAME')
        if not security_group_name:
            logger.error("Environment variable SECURITY_GROUP_NAME is not set.")
            return {"statusCode": 500, "body": "SECURITY_GROUP_NAME not set."}

        security_group_id = get_security_group_id(vpc_id, security_group_name)
        if not security_group_id:
            logger.error(f"Security group with name {security_group_name} not found in VPC {vpc_id}.")
            return {"statusCode": 404, "body": "Security group not found."}

        update_security_group(instance_id, security_group_id)
        return {"statusCode": 200, "body": json.dumps({"InstanceId": instance_id, "message": "Security group updated successfully"})}
    
    except Exception as e:
        logger.error(f"An unexpected error occurred: {str(e)}")
        return {"statusCode": 500, "body": json.dumps({"error": "An unexpected error occurred."})}


def get_vpc_id(instance_id):
    response = ec2_client.describe_instances(InstanceIds=[instance_id])
    return response['Reservations'][0]['Instances'][0]['VpcId']


def get_security_group_id(vpc_id, security_group_name):
    response = ec2_client.describe_security_groups(
        Filters=[
            {'Name': 'vpc-id', 'Values': [vpc_id]},
            {'Name': 'group-name', 'Values': [security_group_name]}
        ]
    )
    groups = response.get('SecurityGroups', [])
    return groups[0]['GroupId'] if groups else None


def update_security_group(instance_id, security_group_id):
    logger.info(f"Updating security group for instance {instance_id} to {security_group_id}...")
    try:
        ec2_client.modify_instance_attribute(
            InstanceId=instance_id,
            Groups=[security_group_id]
        )
        logger.info(f"Security group updated for instance {instance_id}.")
    except (BotoCoreError, ClientError) as e:
        logger.error(f"Error updating security group: {str(e)}")
        raise
