import json
import logging
import requests
import boto3
import os
from botocore.exceptions import BotoCoreError, ClientError


logger = logging.getLogger()
logger.setLevel(logging.INFO)

ec2_client = boto3.client('ec2')

def lambda_handler(event, context):
    print("Event received")
    
    try:
        # Payload parsing
        detail_data = event.get("detail", {})

        # Find INSTANCE_ID in JSON
        instance_id = (
            detail_data.get("EVENT_DETAILS", {})
            .get("data", [{}])[0]  
            .get("ENTITY_MAP", {})
            .get("Machine", [{}])[0]  
            .get("INSTANCE_ID", None)  
        )

        print(f"Instance ID: {instance_id}")
      
        if not instance_id:
            print("Erro: instance_id not found.")
            return {"statusCode": 400, "body": "event_id not found"}

        # add the tag "fcnappalert" with "true" to the EC2
        add_tag_to_instance(instance_id)
        
        return {
            "statusCode": 200,
            "body": json.dumps({"InstanceId": instance_id, "message": "Tag added successfully"})
        }

    except json.JSONDecodeError:
        logger.error("Invalid JSON payload.")
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "Invalid JSON payload."})
        }
    except requests.exceptions.RequestException as e:
        logger.error(f"Error while calling external API: {str(e)}")
        return {
            "statusCode": 500,
            "body": json.dumps({"error": "Error while calling external API."})
        }
    except Exception as e:
        logger.error(f"An unexpected error occurred: {str(e)}")
        return {
            "statusCode": 500,
            "body": json.dumps({"error": "An unexpected error occurred."})
        }

def add_tag_to_instance(instance_id):
    logger.info("Starting to add the tag...")
    tag_key = os.getenv('TAG_KEY', 'fcnappalert')  # default value
    tag_value = "true"
    try:
        # Add the tag to the EC2
        ec2_client.create_tags(
            Resources=[instance_id],
            Tags=[
                {"Key": tag_key, "Value": tag_value}
            ]
        )
        logger.info(f"Tag 'fcnappalert=true' added to instance {instance_id}.")
    except (BotoCoreError, ClientError) as e:
        logger.error(f"Error adding tag to instance {instance_id}: {str(e)}")
        raise
